
from django.contrib import admin
from django.urls import path
from main import views
urlpatterns = [
    path("", views.index, name='main' ),
    path("about", views.about, name='about' ),
    path("services", views.services, name='services' ),
    path("contect", views.contect, name='contect' ),
    path("profile", views.profile, name='profile' ),
    path("follower", views.follower, name='follower' ),
    path("login", views.loginUser, name='login' ),
    path("logoutUser", views.logoutUser, name='logoutUser' )

    
]