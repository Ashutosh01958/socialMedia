from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import logout, authenticate, login
from django.http import HttpResponse
# Create your views here.
def index(request):
    return render(request, 'login.html')
    print(request.user)
    if request.user.is_anonymous:
        return redirect("/login")
        return render(request, 'index.html')
        return HttpResponse(message)
    
   # return HttpResponse("this is main page")

def about(request):
    return render(request, 'about.html')
   # return HttpResponse("this is about page")

def services(request):
    return render(request, 'services.html')
   # return HttpResponse("this is services page")

def contect(request):
    return render(request, 'contect.html')
   # return HttpResponse("this is contect page")        

def profile(request):
    return render(request, 'profile.html')   

def follower(request):
    return render(request, 'follower.html')    

def loginUser(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        print(User)
        User = authenticate(Username=username, Password=password)
        if User is not None:
            login(request, User)
            return redirect("/")
        else:
            return render(request, 'login.html')
                # No backend authenticated the credentials
    return render(request, 'login.html')    

def logoutUser(request):
    logout(request)
    return redirect('/login')    
